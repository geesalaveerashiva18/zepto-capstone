# Zepto Capstone Project

This repository contains three modules:

| Module | Path | What it does |
|---|---|---|
| 1. Data Pipeline | [`/data_pipeline`](./data_pipeline/README.md) | Scrapes books.toscrape.com, cleans/converts data, loads into a normalized SQLite DB, runs SQL + pandas queries. |
| 2. Analytics Pipeline | [`/analytics`](./analytics/README.md) | Profiles, cleans and visualizes the Titanic dataset, then trains/evaluates/tunes classifiers + a regression side-task. |
| 3. Support Assistant | [`/support_assistant`](./support_assistant/README.md) | A local RAG service (ChromaDB + sentence-transformers + LangGraph + FastAPI) answering Zepto policy questions, fully offline via a deterministic mock-LLM mode. |

## Quick start

Each module is self-contained with its own `requirements.txt` and `README.md`. General flow:

```bash
git clone <this-repo>
cd zepto-capstone

# Module 1
cd data_pipeline
pip install -r requirements.txt
python scrape.py          # scrapes books.toscrape.com -> books_raw.csv
python clean_and_load.py  # cleans, converts currency, builds books.db
python run_queries.py     # runs the 5+ SQL queries + pandas equivalents

# Module 2
cd ../analytics
pip install -r requirements.txt
python 01_eda.py          # loads titanic (network first run), cleans, saves titanic.csv, EDA charts
python 02_modeling.py     # reads titanic.csv, trains/evaluates/tunes models, saves pipeline.joblib

# Module 3
cd ../support_assistant
pip install -r requirements.txt
python ingest.py          # embeds docs/ into ChromaDB
uvicorn main:app --reload --port 7860
# in another terminal:
curl -X POST localhost:7860/ask -H "Content-Type: application/json" -d '{"query":"What is your delivery fee?"}'
```

## Repo/branch workflow

All module work was done on a feature branch (`feature/capstone-modules`) with multiple commits, then merged into `main` — see `git log --graph --oneline --all`.
