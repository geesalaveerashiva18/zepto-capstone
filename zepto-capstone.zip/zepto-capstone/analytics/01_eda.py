"""
Module 2 - Analytics Pipeline, Part A
Profiling, cleaning, and the data story for the Titanic dataset.

This is the ONE and ONLY place the raw dataset is loaded from
network/cache (sns.load_dataset). Immediately after loading we save
titanic.csv as a committed offline fallback so grading can proceed via
pd.read_csv("titanic.csv") with no network access. 02_modeling.py reads
that same titanic.csv and never calls sns.load_dataset again.
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.preprocessing import StandardScaler

CHARTS_DIR = "charts"
os.makedirs(CHARTS_DIR, exist_ok=True)


def savefig(name):
    path = os.path.join(CHARTS_DIR, name)
    plt.tight_layout()
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"Saved chart -> {path}")


# ---------------------------------------------------------------------------
# 1. Load + profile (the one and only raw load)
# ---------------------------------------------------------------------------
def load_and_profile() -> pd.DataFrame:
    df = sns.load_dataset("titanic")  # needs network on first run; then cached locally
    df.to_csv("titanic.csv", index=False)  # committed offline fallback
    print("Saved raw offline fallback -> titanic.csv")

    print("\n=== df.info() ===")
    df.info()
    print("\n=== df.describe() ===")
    print(df.describe(include="all"))
    print(f"\n=== df.shape === {df.shape}")

    print("\n=== Missing value % per column (only columns with any missing) ===")
    missing_pct = (df.isna().mean() * 100).round(2)
    missing_pct = missing_pct[missing_pct > 0].sort_values(ascending=False)
    print(missing_pct)

    return df, missing_pct


# ---------------------------------------------------------------------------
# 2. Missing-value handling (threshold rule)
# ---------------------------------------------------------------------------
def clean_missing(df: pd.DataFrame, missing_pct: pd.Series) -> pd.DataFrame:
    df = df.copy()
    print("\n=== Missing-value handling decisions ===")
    for col, pct in missing_pct.items():
        if pct < 5:
            df = df.dropna(subset=[col])
            print(f"{col}: {pct}% missing (<5%) -> dropped rows with missing values")
        elif pct <= 30:
            if df[col].dtype in ("float64", "int64"):
                fill_value = df[col].median()
                df[col] = df[col].fillna(fill_value)
                print(f"{col}: {pct}% missing (5-30%) -> imputed with median ({fill_value:.2f})")
            else:
                fill_value = df[col].mode(dropna=True)[0]
                df[col] = df[col].fillna(fill_value)
                print(f"{col}: {pct}% missing (5-30%) -> imputed with mode ('{fill_value}')")
        else:
            # >30% missing: imputation would be unreliable.
            # 'deck' is ~77% missing in the raw seaborn titanic dataset - too sparse
            # to impute meaningfully, but "missing" itself may carry information
            # (e.g. lower-class passengers whose deck was never recorded), so we
            # encode missingness as its own explicit category rather than dropping
            # the column outright or fabricating a deck for 3 in 4 passengers.
            df[col] = df[col].astype("object").fillna("Missing")
            print(f"{col}: {pct}% missing (>30%) -> too unreliable to impute; encoded 'Missing' as its own category")
    return df


# ---------------------------------------------------------------------------
# 3. Univariate analysis: age & fare
# ---------------------------------------------------------------------------
def iqr_outliers(series: pd.Series):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = series[(series < lower) | (series > upper)]
    return len(outliers), lower, upper


def univariate_analysis(df: pd.DataFrame):
    print("\n=== Univariate analysis: age & fare ===")
    for col in ["age", "fare"]:
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        sns.histplot(df[col], kde=True, ax=axes[0])
        axes[0].set_title(f"{col} - histogram")
        sns.boxplot(x=df[col], ax=axes[1])
        axes[1].set_title(f"{col} - boxplot")
        savefig(f"univariate_{col}.png")

        n_out, lower, upper = iqr_outliers(df[col])
        print(f"{col}: {n_out} IQR outliers (bounds: [{lower:.2f}, {upper:.2f}])")

    mean_fare = df["fare"].mean()
    median_fare = df["fare"].median()
    mode_fare = df["fare"].mode()[0]
    print(f"\nfare -> mean={mean_fare:.2f}, median={median_fare:.2f}, mode={mode_fare:.2f}")
    if mean_fare > median_fare > mode_fare:
        skew = "right-skewed (mean > median > mode): a long tail of high fares pulls the mean up"
    elif mean_fare < median_fare < mode_fare:
        skew = "left-skewed (mean < median < mode)"
    else:
        skew = "roughly symmetric"
    print(f"fare distribution: {skew}")


# ---------------------------------------------------------------------------
# 4. Bivariate analysis
# ---------------------------------------------------------------------------
def bivariate_analysis(df: pd.DataFrame):
    print("\n=== Bivariate analysis: survival rate breakdowns ===")

    for sex in df["sex"].unique():
        mask = df["sex"] == sex
        rate = df.loc[mask, "survived"].mean()
        print(f"Survival rate | sex={sex}: {rate:.3f}")

    for pclass in sorted(df["pclass"].unique()):
        mask = df["pclass"] == pclass
        rate = df.loc[mask, "survived"].mean()
        print(f"Survival rate | pclass={pclass}: {rate:.3f}")

    for sex in df["sex"].unique():
        for pclass in sorted(df["pclass"].unique()):
            mask = (df["sex"] == sex) & (df["pclass"] == pclass)
            rate = df.loc[mask, "survived"].mean()
            print(f"Survival rate | sex={sex} & pclass={pclass}: {rate:.3f}")

    corr_cols = ["survived", "pclass", "age", "sibsp", "parch", "fare"]
    corr = df[corr_cols].corr()
    print("\n=== Correlation matrix (6 numeric columns) ===")
    print(corr.round(3))

    plt.figure(figsize=(6, 5))
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation heatmap (survived, pclass, age, sibsp, parch, fare)")
    savefig("correlation_heatmap.png")

    # Top 2 strongest off-diagonal correlations by absolute value
    pairs = []
    for i, c1 in enumerate(corr_cols):
        for c2 in corr_cols[i + 1 :]:
            pairs.append((c1, c2, corr.loc[c1, c2]))
    pairs.sort(key=lambda x: abs(x[2]), reverse=True)
    print("\nTop 2 strongest correlations:")
    for c1, c2, val in pairs[:2]:
        print(f"  {c1} <-> {c2}: {val:.3f}")


# ---------------------------------------------------------------------------
# 5. Multivariate "data story" - >= 4 charts with interpretation
# ---------------------------------------------------------------------------
def multivariate_story(df: pd.DataFrame):
    print("\n=== Multivariate data story (charts saved to charts/) ===")

    plt.figure(figsize=(6, 4))
    sns.barplot(data=df, x="pclass", y="survived", hue="sex")
    plt.title("Survival rate by class and sex")
    savefig("story_1_survival_by_class_sex.png")
    print(
        "Chart 1 (bar): Survival rate by class and sex. Women survived at a much higher "
        "rate than men in every class, and 1st-class passengers of both sexes fared "
        "better than 3rd-class passengers - suggesting both 'women and children first' "
        "evacuation norms and class-based access to lifeboats were at play."
    )

    plt.figure(figsize=(6, 4))
    sns.boxplot(data=df, x="survived", y="age")
    plt.title("Age distribution by survival")
    savefig("story_2_age_by_survival.png")
    print(
        "Chart 2 (box): Age distribution split by survival. Median age is similar "
        "between the two groups, but survivors show a slightly wider spread toward "
        "younger ages, consistent with children being prioritized during evacuation."
    )

    plt.figure(figsize=(6, 4))
    sns.scatterplot(data=df, x="age", y="fare", hue="survived", alpha=0.6)
    plt.title("Age vs Fare, colored by survival")
    savefig("story_3_age_fare_survival_scatter.png")
    print(
        "Chart 3 (scatter): Age vs fare colored by survival. Higher-fare passengers "
        "(who were disproportionately 1st class) survived more often regardless of "
        "age, reinforcing that ticket price/class was a stronger survival signal than "
        "age alone."
    )

    plt.figure(figsize=(6, 4))
    sns.barplot(data=df, x="embarked", y="survived")
    plt.title("Survival rate by port of embarkation")
    savefig("story_4_survival_by_embarked.png")
    print(
        "Chart 4 (bar): Survival rate by embarkation port. Passengers who boarded at "
        "Cherbourg show a higher survival rate than those from Southampton or "
        "Queenstown - largely a proxy effect, since Cherbourg had a higher share of "
        "1st-class passengers, again pointing back to class as the underlying driver."
    )


# ---------------------------------------------------------------------------
# 6. Exploratory standardization check (not used by the modeling pipeline)
# ---------------------------------------------------------------------------
def standardization_check(df: pd.DataFrame):
    print("\n=== Exploratory z-score standardization check (age, fare) ===")
    scaler = StandardScaler()
    scaled = scaler.fit_transform(df[["age", "fare"]])
    scaled_df = pd.DataFrame(scaled, columns=["age_z", "fare_z"])

    print("Before standardization:")
    print(df[["age", "fare"]].agg(["mean", "std"]))
    print("\nAfter standardization:")
    print(scaled_df.agg(["mean", "std"]))
    print(
        "\n(Approximately mean=0, std=1 for both columns, confirming the z-score "
        "transform worked as expected. This is purely an EDA sanity check - the "
        "modeling pipeline in 02_modeling.py performs its own train-only scaling.)"
    )


def main():
    df, missing_pct = load_and_profile()
    df = clean_missing(df, missing_pct)
    univariate_analysis(df)
    bivariate_analysis(df)
    multivariate_story(df)
    standardization_check(df)
    print("\nPart A (EDA) complete.")


if __name__ == "__main__":
    main()
