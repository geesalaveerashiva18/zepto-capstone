# Module 2 — Analytics Pipeline

The Titanic dataset (loaded once via `sns.load_dataset('titanic')`) is profiled, cleaned,
visualized (Part A, `01_eda.py`), and then used to train/evaluate/tune a full
classification pipeline plus a regression side-task (Part B, `02_modeling.py`).

## Install & run

```bash
pip install -r requirements.txt
python 01_eda.py       # loads titanic (network on first run only) -> titanic.csv, charts/
python 02_modeling.py  # reads titanic.csv -> trains/evaluates/tunes models, pipeline.joblib
```

`01_eda.py` is the **only** place `sns.load_dataset('titanic')` is called. It saves the
raw DataFrame to `titanic.csv` immediately after loading, so `02_modeling.py` (and
grading, if offline) can run entirely from `pd.read_csv("titanic.csv")`.

## Part A — Profiling, cleaning, data story

- `df.info()`, `df.describe()`, `df.shape`, and per-column missing-% are printed at the
  top of the run.
- **Missing-value strategy** (threshold rule, exact % measured each run):
  - `< 5%` missing → drop those rows (e.g. `embarked`, `embark_town`: ~0.2%).
  - `5%–30%` missing → impute (median for numeric, mode for categorical) (e.g. `age`:
    ~19.9%).
  - `> 30%` missing → too unreliable to impute; encoded as its own `"Missing"` category
    rather than dropped, since absence of a recorded deck may itself be informative
    (e.g. `deck`: ~77.2%).
- **Univariate**: histogram + boxplot for `age` and `fare`, IQR-based outlier counts for
  both, and a mean/median/mode comparison for `fare` with a written skew conclusion
  (right-skewed: a small number of very high fares pull the mean above the median and
  mode).
- **Bivariate**: survival rate by sex, by pclass, and by sex+pclass jointly (via boolean
  masking), plus a 6×6 correlation heatmap over `survived, pclass, age, sibsp, parch,
  fare` (deliberately excluding the derived/redundant `adult_male` and `alone` flags),
  with the two strongest correlations named and interpreted.
- **Multivariate data story**: 4 charts (bar/box/scatter/bar), each with a 2-4 sentence
  interpretation, building toward the conclusion that **passenger class / fare (a proxy
  for wealth) and sex were the two dominant survival factors**, with age playing a
  smaller, mostly-child-related role.
- **Standardization sanity check**: z-scoring `age`/`fare` on the full cleaned data and
  confirming mean≈0, std≈1. This is EDA-only; it does **not** feed the modeling
  pipeline, which does its own train-only scaling in Part B.

All charts are saved to `analytics/charts/`.

## Part B — Predictive modeling

- **Stratified train/test split** (80/20) on `survived`, justified by the dataset's
  ~38%/62% survived/not-survived class balance — a plain random split risks skewing that
  ratio between train and test and biasing evaluation.
- **Preprocessing** via a `ColumnTransformer` (median-impute + scale numeric columns;
  mode-impute + one-hot encode `sex`/`embarked`), fit only on the training split inside
  each model's `Pipeline` — never on the full dataset or the test split.
- **Three classifiers** (Logistic Regression, Decision Tree, Random Forest) trained on
  the identical split; the Decision Tree is rendered with `plot_tree` (feature + class
  names labeled). All three are evaluated with confusion matrix, accuracy, precision,
  recall, F1, and ROC/AUC, summarized in one comparison table.
- **Imbalance comparison**: baseline vs. `class_weight='balanced'` vs. SMOTE (SMOTE
  applied only inside the training fold via an `imblearn` pipeline, so it never touches
  the test set), compared on precision/recall/F1 with a written conclusion.
- **Hyperparameter tuning**: `GridSearchCV` over the Random Forest's `n_estimators`,
  `max_depth`, `max_features`; best params and the resulting `oob_score_` (from
  `RandomForestClassifier(oob_score=True, bootstrap=True, ...)`) are reported.
- **Regression side-task**: predicts `fare` from the other features with
  `LinearRegression`, reporting MAE, RMSE, R², Adjusted R², and a residual plot — the
  spread of residuals widens as predicted fare increases, indicating
  **heteroscedasticity**.
- **Final comparison table** presents classifier metrics and regression metrics as two
  separate metric groups (they're on different scales), plus a written recommendation of
  which classifier to deploy, referencing its specific metric values.
- **Deployment artifact**: the tuned Random Forest's full `Pipeline` (preprocessing +
  estimator together) is saved with `joblib.dump(...)` to `pipeline.joblib`, then
  reloaded with `joblib.load(...)` and shown predicting correctly on a raw,
  unpreprocessed sample passenger — never the bare estimator alone.

## Files

- `01_eda.py`, `02_modeling.py` — the two ordered stages of one pipeline.
- `titanic.csv` — committed raw offline fallback (produced by `01_eda.py`).
- `charts/` — all saved PNG charts (histograms, boxplots, heatmap, ROC curves, decision
  tree, residual plot, data-story charts).
- `pipeline.joblib` — the saved, deployable, fully-fitted classification pipeline.
