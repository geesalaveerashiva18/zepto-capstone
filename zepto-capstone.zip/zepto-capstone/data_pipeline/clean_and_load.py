"""
Module 1 - Data Pipeline
Cleans books_raw.csv, converts currency using the fixed project baseline rate,
and loads everything into a normalized SQLite database (books.db).

Fixed baseline conversion rate (per assignment spec, NOT a live/market rate):
    1 GBP = 105.50 INR
"""

import sqlite3

import pandas as pd

GBP_TO_INR_RATE = 105.50  # fixed, project-defined constant - see README
RAW_CSV = "books_raw.csv"
DB_PATH = "books.db"

RATING_WORD_TO_INT = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}


def parse_price(price_text: str):
    """'£51.77' -> 51.77 (float). Returns None if it can't be parsed."""
    try:
        cleaned = price_text.replace("£", "").replace("Â", "").strip()
        return float(cleaned)
    except (ValueError, AttributeError):
        return None


def parse_rating(word: str):
    return RATING_WORD_TO_INT.get(word.strip(), None) if isinstance(word, str) else None


def parse_availability(text: str):
    """'In stock (22 available)' -> True, 'Out of stock' -> False, else None."""
    if not isinstance(text, str):
        return None
    lowered = text.lower()
    if "in stock" in lowered:
        return True
    if "out of stock" in lowered:
        return False
    return None


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["price_gbp"] = df["price"].apply(parse_price)
    df["rating"] = df["star_rating"].apply(parse_rating)
    df["in_stock"] = df["availability"].apply(parse_availability)

    # --- Handling rows/fields that fail to parse ---
    # price_gbp (numeric): median-impute any failures, since price is a
    # continuous numeric field and a single row's price rarely changes the
    # overall pricing story - dropping it would lose category/rating info
    # for no good reason.
    n_price_failures = df["price_gbp"].isna().sum()
    if n_price_failures:
        median_price = df["price_gbp"].median()
        df["price_gbp"] = df["price_gbp"].fillna(median_price)
        print(f"Median-imputed {n_price_failures} unparseable price_gbp value(s) with {median_price:.2f}")

    # rating / in_stock (categorical/boolean): these can't be meaningfully
    # "averaged", and books.toscrape.com always encodes them in a fixed,
    # predictable format, so a parse failure signals a genuinely malformed
    # row rather than expected messiness - we drop those rows instead of
    # inventing a fake rating/availability.
    before = len(df)
    df = df.dropna(subset=["rating", "in_stock"])
    dropped = before - len(df)
    if dropped:
        print(f"Dropped {dropped} row(s) with unparseable rating/availability")

    df["rating"] = df["rating"].astype(int)
    df["in_stock"] = df["in_stock"].astype(bool)

    # --- Currency conversion (fixed baseline rate) ---
    df["price_inr"] = (df["price_gbp"] * GBP_TO_INR_RATE).round(2)

    return df[["title", "price_gbp", "price_inr", "rating", "in_stock", "category"]]


def load_to_sqlite(df: pd.DataFrame, db_path: str = DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.executescript(
        """
        DROP TABLE IF EXISTS books;
        DROP TABLE IF EXISTS categories;

        CREATE TABLE categories (
            category_id INTEGER PRIMARY KEY,
            category_name TEXT UNIQUE
        );

        CREATE TABLE books (
            book_id INTEGER PRIMARY KEY,
            title TEXT,
            price_gbp REAL,
            price_inr REAL,
            rating INTEGER,
            in_stock INTEGER,
            category_id INTEGER REFERENCES categories(category_id)
        );
        """
    )

    categories = sorted(df["category"].unique())
    cur.executemany(
        "INSERT INTO categories (category_name) VALUES (?)",
        [(c,) for c in categories],
    )
    conn.commit()

    cat_id_map = dict(cur.execute("SELECT category_name, category_id FROM categories").fetchall())

    book_rows = [
        (
            row.title,
            row.price_gbp,
            row.price_inr,
            row.rating,
            int(row.in_stock),
            cat_id_map[row.category],
        )
        for row in df.itertuples(index=False)
    ]
    cur.executemany(
        """INSERT INTO books (title, price_gbp, price_inr, rating, in_stock, category_id)
           VALUES (?, ?, ?, ?, ?, ?)""",
        book_rows,
    )
    conn.commit()
    conn.close()
    print(f"Loaded {len(book_rows)} books across {len(categories)} categories into {db_path}")


def main():
    raw = pd.read_csv(RAW_CSV)
    cleaned = clean(raw)
    cleaned.to_csv("books_clean.csv", index=False)
    load_to_sqlite(cleaned)


if __name__ == "__main__":
    main()
