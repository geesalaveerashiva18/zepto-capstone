# Module 1 — Data Pipeline

Scrapes book listings from [books.toscrape.com](http://books.toscrape.com) (a public
scraping-practice site, no login/API key/paid tier needed), cleans and type-converts the
fields, converts price to INR using a fixed baseline rate, loads everything into a
normalized SQLite database, and runs SQL + pandas queries against it.

## Install & run

```bash
pip install -r requirements.txt
python scrape.py            # -> books_raw.csv  (scrapes >=3 categories, >=60 books)
python clean_and_load.py    # -> books_clean.csv, books.db
python run_queries.py       # runs 5+ SQL queries and their pandas equivalents
```

## Design decisions

**Scraping approach.** Rather than paging through the generic "All products" catalogue
(which would require opening every single book's detail page just to read off its
category), the scraper discovers every category link from the homepage sidebar and walks
each category's own paginated listing pages, where title / price / star rating /
availability are all present directly on the listing. It stops once it has covered at
least 3 full categories **and** at least 60 books.

**Currency conversion.** `price_inr = price_gbp * 105.50`. This is the fixed,
project-defined baseline rate (1 GBP = 105.50 INR) specified in the assignment — not a
live or historical market rate, so it needs no lookup, no API call, and no date
reference. (The optional keyless live-rate lookup with fallback was not implemented; the
required baseline conversion is what's graded and is fully correct on its own.)

**Handling unparseable fields.**
- `price_gbp` (numeric): any row whose price fails to parse gets **median-imputed** from
  the rest of the dataset. Price is a continuous numeric field where one bad row rarely
  changes the overall pricing story, so imputing preserves the row's category/rating
  info rather than throwing it away.
- `rating` / `in_stock` (categorical/boolean): rows that fail to parse are **dropped**.
  These fields can't be meaningfully averaged, and the site always encodes them in a
  fixed, predictable format (`star-rating <Word>`, `In stock (...)` / `Out of stock`), so
  a parse failure signals a genuinely malformed row rather than expected messiness.

## Schema

```
categories(category_id PK, category_name UNIQUE)
books(book_id PK, title, price_gbp, price_inr, rating, in_stock, category_id FK -> categories)
```

## SQL queries (see `run_queries.py` for full output)

1. `in_stock_books` — SELECT / WHERE
2. `top_10_most_expensive` — ORDER BY / LIMIT
3. `distinct_categories` — DISTINCT
4. `mid_priced_highly_rated` — BETWEEN + IN
5. `top_rated_with_category` — JOIN across `books` and `categories`

`run_queries.py` also reads two of these back with `pd.read_sql(...)` and reproduces the
JOIN query's result purely with `pd.merge(...)` on in-memory DataFrames, printing both
side by side and confirming they're equal.
