"""
Module 1 - Data Pipeline
Runs the required SQL queries against books.db, then reproduces two of them
with pandas (pd.read_sql) and the join query with pd.merge on in-memory
DataFrames (no SQL), showing both approaches agree.
"""

import sqlite3

import pandas as pd

DB_PATH = "books.db"

QUERIES = {
    # 1. SELECT / WHERE
    "in_stock_books": """
        SELECT title, price_gbp, rating
        FROM books
        WHERE in_stock = 1;
    """,
    # 2. ORDER BY + LIMIT
    "top_10_most_expensive": """
        SELECT title, price_gbp
        FROM books
        ORDER BY price_gbp DESC
        LIMIT 10;
    """,
    # 3. DISTINCT
    "distinct_categories": """
        SELECT DISTINCT category_name
        FROM categories;
    """,
    # 4. BETWEEN (numeric range) - and IN (rating in a set)
    "mid_priced_highly_rated": """
        SELECT title, price_gbp, rating
        FROM books
        WHERE price_gbp BETWEEN 10 AND 30
          AND rating IN (4, 5);
    """,
    # 5. JOIN - top 10 highest-rated books per... (here: overall, with category name)
    "top_rated_with_category": """
        SELECT b.title, b.rating, b.price_gbp, c.category_name
        FROM books b
        JOIN categories c ON b.category_id = c.category_id
        ORDER BY b.rating DESC, b.price_gbp DESC
        LIMIT 10;
    """,
}


def run_sql_queries(conn: sqlite3.Connection):
    cur = conn.cursor()
    for name, sql in QUERIES.items():
        print(f"\n=== SQL query: {name} ===")
        print(sql.strip())
        rows = cur.execute(sql).fetchall()
        cols = [d[0] for d in cur.description]
        print(f"-> {len(rows)} rows. Sample:")
        for r in rows[:5]:
            print(dict(zip(cols, r)))


def run_pandas_equivalents(conn: sqlite3.Connection):
    print("\n\n=== pd.read_sql equivalents ===")

    df_in_stock = pd.read_sql(QUERIES["in_stock_books"], conn)
    print(f"\n[pd.read_sql] in_stock_books -> {len(df_in_stock)} rows")
    print(df_in_stock.head())

    df_top10 = pd.read_sql(QUERIES["top_10_most_expensive"], conn)
    print(f"\n[pd.read_sql] top_10_most_expensive -> {len(df_top10)} rows")
    print(df_top10.head())

    # Reproduce the JOIN query result using pd.merge on in-memory DataFrames (no SQL)
    print("\n=== JOIN reproduced with pd.merge (no SQL) ===")
    books_df = pd.read_sql("SELECT * FROM books", conn)
    categories_df = pd.read_sql("SELECT * FROM categories", conn)

    merged = books_df.merge(categories_df, on="category_id", how="inner")
    merged = merged.sort_values(["rating", "price_gbp"], ascending=[False, False]).head(10)
    merged = merged[["title", "rating", "price_gbp", "category_name"]].reset_index(drop=True)

    sql_join_result = pd.read_sql(QUERIES["top_rated_with_category"], conn).reset_index(drop=True)

    print("\nSQL JOIN result:")
    print(sql_join_result)
    print("\npd.merge result:")
    print(merged)

    are_equal = sql_join_result.reset_index(drop=True).equals(merged.reset_index(drop=True))
    print(f"\nSQL JOIN result and pd.merge result are equal: {are_equal}")


def main():
    conn = sqlite3.connect(DB_PATH)
    run_sql_queries(conn)
    run_pandas_equivalents(conn)
    conn.close()


if __name__ == "__main__":
    main()
