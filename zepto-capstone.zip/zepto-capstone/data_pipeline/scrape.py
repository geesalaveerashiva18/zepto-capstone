"""
Module 1 - Data Pipeline
Scrapes books.toscrape.com across multiple categories and writes a raw CSV.

Strategy
--------
books.toscrape.com's category pages already show title / price / star rating /
availability directly in the listing (no need to open each book's detail page
just to get the category - the category page IS the category). So we:

  1. Fetch the homepage and discover every category link from the sidebar nav.
  2. Visit categories one at a time. For each category, walk its paginated
     listing pages (following the "next" link) and scrape every book_pod.
  3. Stop once we have >= MIN_BOOKS books across >= MIN_CATEGORIES categories
     (but always finish the category we're currently on, and always do at
     least MIN_CATEGORIES categories fully).

This yields a dataset with >= 60 rows across >= 3 categories, satisfying the
module's acceptance criteria, without any manual copy-pasting.
"""

import csv
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE_URL = "http://books.toscrape.com/"
MIN_BOOKS = 60
MIN_CATEGORIES = 3
OUTPUT_CSV = "books_raw.csv"
REQUEST_DELAY_SECONDS = 0.3  # be polite even to a scraping-practice site


def get_soup(url: str) -> BeautifulSoup:
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return BeautifulSoup(resp.text, "html.parser")


def discover_categories() -> list[tuple[str, str]]:
    """Returns list of (category_name, category_url)."""
    soup = get_soup(BASE_URL)
    nav = soup.select("div.side_categories ul.nav-list li ul li a")
    categories = []
    for a in nav:
        name = a.get_text(strip=True)
        url = urljoin(BASE_URL, a["href"])
        categories.append((name, url))
    return categories


def scrape_category(name: str, start_url: str) -> list[dict]:
    """Walks all paginated pages of one category, returns list of book dicts."""
    rows = []
    url = start_url
    while url:
        soup = get_soup(url)
        for pod in soup.select("article.product_pod"):
            title = pod.h3.a["title"].strip()
            price_text = pod.select_one("p.price_color").get_text(strip=True)
            # star rating is encoded as the 2nd CSS class, e.g. "star-rating Three"
            rating_classes = pod.select_one("p.star-rating")["class"]
            star_rating = [c for c in rating_classes if c != "star-rating"][0]
            availability = pod.select_one("p.instock.availability").get_text(strip=True)
            rows.append(
                {
                    "title": title,
                    "price": price_text,
                    "star_rating": star_rating,
                    "availability": availability,
                    "category": name,
                }
            )
        next_link = soup.select_one("li.next a")
        url = urljoin(url, next_link["href"]) if next_link else None
        time.sleep(REQUEST_DELAY_SECONDS)
    return rows


def main():
    categories = discover_categories()
    if not categories:
        raise RuntimeError("Could not discover any categories - check site structure/connectivity.")

    all_rows: list[dict] = []
    categories_done = 0

    for name, url in categories:
        print(f"Scraping category: {name} ...")
        rows = scrape_category(name, url)
        print(f"  -> {len(rows)} books")
        all_rows.extend(rows)
        categories_done += 1

        if categories_done >= MIN_CATEGORIES and len(all_rows) >= MIN_BOOKS:
            break

    print(f"\nTotal scraped: {len(all_rows)} books across {categories_done} categories")
    assert len(all_rows) >= MIN_BOOKS, "Did not reach the minimum of 60 books - widen category scope."
    assert categories_done >= MIN_CATEGORIES, "Did not reach the minimum of 3 categories."

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["title", "price", "star_rating", "availability", "category"])
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"Saved raw scraped data to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
