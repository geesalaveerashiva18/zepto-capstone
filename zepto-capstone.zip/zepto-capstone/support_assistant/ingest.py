"""
Module 3 - Support Assistant
Loads the 8 policy documents, chunks them (one chunk per document - each
doc is a single short paragraph, so no further splitting is needed), embeds
each chunk locally with sentence-transformers (all-MiniLM-L6-v2, no API key,
no cost), and stores the embeddings in a persistent ChromaDB collection.

Run this once before starting the API (`python ingest.py`), then `main.py`
just opens the already-populated collection.
"""

import glob
import os

import chromadb
from sentence_transformers import SentenceTransformer

DOCS_DIR = "docs"
PERSIST_DIR = "chroma_db"
COLLECTION_NAME = "zepto_policies"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"


def load_documents() -> list[dict]:
    """One chunk per document file - each doc_XX.txt is already a short,
    single-topic paragraph, so per-document chunking is the natural
    granularity here (no need for further fixed-size splitting)."""
    paths = sorted(glob.glob(os.path.join(DOCS_DIR, "doc_*.txt")))
    chunks = []
    for path in paths:
        doc_id = os.path.splitext(os.path.basename(path))[0]  # e.g. "doc_01"
        with open(path, "r", encoding="utf-8") as f:
            text = f.read().strip()
        chunks.append({"id": doc_id, "text": text})
    return chunks


def build_index():
    chunks = load_documents()
    print(f"Loaded {len(chunks)} document chunks from {DOCS_DIR}/")

    model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    embeddings = model.encode([c["text"] for c in chunks]).tolist()

    client = chromadb.PersistentClient(path=PERSIST_DIR)
    # Start clean each time ingest.py is run
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    collection = client.create_collection(COLLECTION_NAME)

    collection.add(
        ids=[c["id"] for c in chunks],
        documents=[c["text"] for c in chunks],
        embeddings=embeddings,
    )
    print(f"Stored {len(chunks)} embedded chunks in ChromaDB collection '{COLLECTION_NAME}' at {PERSIST_DIR}/")


if __name__ == "__main__":
    build_index()
