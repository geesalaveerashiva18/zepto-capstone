"""
Module 3 - Support Assistant
LangGraph StateGraph with 3 nodes (classify_intent, retrieve_and_answer,
direct_answer) and a conditional edge routing between them.

MOCK_LLM toggle (env var):
  - unset or "1" (default, GRADED BASELINE): fully deterministic, offline,
    rule-based logic. No LLM call anywhere in the graph.
  - "0" (OPTIONAL, ungraded extension): classify_intent and the generation
    steps call a real LLM (Groq free tier) instead.

Retrieval itself (embedding the query + querying ChromaDB) always runs for
real in BOTH modes - it needs no API key and no network call, so there is
nothing to mock there. Only the *generation* step branches on MOCK_LLM.
"""

import json
import os
from typing import List, TypedDict

import chromadb
from langgraph.graph import END, StateGraph
from pydantic import ValidationError
from sentence_transformers import SentenceTransformer

from prompt_template import build_prompt
from schemas import AnswerResponse

MAX_LLM_RETRIES = 2  # up to 2 ADDITIONAL retries after the first attempt (3 total)

MOCK_LLM = os.environ.get("MOCK_LLM", "1") != "0"

POLICY_KEYWORDS = [
    "delivery",
    "return",
    "refund",
    "membership",
    "tracking",
    "cancel",
    "gift card",
    "support hours",
]

PERSIST_DIR = "chroma_db"
COLLECTION_NAME = "zepto_policies"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
TOP_K = 3

_embedding_model = None
_collection = None


def _get_embedding_model() -> SentenceTransformer:
    global _embedding_model
    if _embedding_model is None:
        _embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return _embedding_model


def _get_collection():
    global _collection
    if _collection is None:
        client = chromadb.PersistentClient(path=PERSIST_DIR)
        _collection = client.get_collection(COLLECTION_NAME)
    return _collection


def _call_real_llm(prompt: str) -> str:
    """Optional MOCK_LLM=0 extension - calls Groq's free-tier API.
    Only ever invoked when MOCK_LLM=0 is explicitly set."""
    from groq import Groq  # imported lazily so it's not required in mock mode

    client = Groq(api_key=os.environ["GROQ_API_KEY"])
    completion = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
    )
    return completion.choices[0].message.content


def _generate_structured_answer_with_retry(prompt: str, allowed_sources: List[str]) -> AnswerResponse:
    """Optional MOCK_LLM=0 extension only. Asks the real LLM to return JSON
    matching the AnswerResponse schema; validates with Pydantic; on failure,
    retries up to MAX_LLM_RETRIES additional times with a corrective
    instruction before giving up and returning a clearly marked error
    response. Never used in the graded mock baseline (nothing to validate
    there since no LLM output is ever generated)."""
    schema_instruction = (
        "\n\nRespond with ONLY a JSON object (no other text) matching exactly this shape: "
        '{"answer": "<string>", "sources": ' + json.dumps(allowed_sources) + ', "confidence": <float 0-1>}'
    )
    current_prompt = prompt + schema_instruction

    for attempt in range(MAX_LLM_RETRIES + 1):
        raw = _call_real_llm(current_prompt)
        try:
            cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            parsed = json.loads(cleaned)
            return AnswerResponse(**parsed)
        except (json.JSONDecodeError, ValidationError, TypeError) as exc:
            if attempt < MAX_LLM_RETRIES:
                current_prompt = (
                    prompt
                    + schema_instruction
                    + f"\n\nYour previous response was invalid ({exc}). "
                    "Return ONLY valid JSON matching the exact shape above - no markdown, no extra text."
                )
                continue

    return AnswerResponse(
        answer="[error] The assistant could not produce a validly structured response after retries.",
        sources=[],
        confidence=0.0,
    )


class GraphState(TypedDict):
    query: str
    intent: str
    retrieved_chunks: List[dict]
    answer: str
    sources: List[str]
    confidence: float


def classify_intent(state: GraphState) -> GraphState:
    query = state["query"]
    if MOCK_LLM:
        # Mock mode (graded baseline): keyword heuristic, no LLM call.
        lowered = query.lower()
        intent = "policy_question" if any(kw in lowered for kw in POLICY_KEYWORDS) else "general_question"
    else:
        # Optional MOCK_LLM=0 extension: ask the LLM to classify instead.
        classify_prompt = (
            "Classify the following customer question as exactly one word, "
            "either 'policy_question' (about Zepto delivery/returns/refunds/"
            "membership/tracking/cancellation/gift cards/support hours) or "
            f"'general_question' (anything else).\n\nQuestion: {query}\n\nAnswer with one word."
        )
        raw = _call_real_llm(classify_prompt).strip().lower()
        intent = "policy_question" if "policy" in raw else "general_question"

    state["intent"] = intent
    return state


def route_by_intent(state: GraphState) -> str:
    return "retrieve_and_answer" if state["intent"] == "policy_question" else "direct_answer"


def retrieve_and_answer(state: GraphState) -> GraphState:
    query = state["query"]

    # Retrieval always runs for real in both modes (local model + local DB).
    model = _get_embedding_model()
    collection = _get_collection()
    query_embedding = model.encode([query]).tolist()
    results = collection.query(query_embeddings=query_embedding, n_results=TOP_K)

    chunk_ids = results["ids"][0]
    chunk_texts = results["documents"][0]
    retrieved_chunks = [{"id": cid, "text": text} for cid, text in zip(chunk_ids, chunk_texts)]
    state["retrieved_chunks"] = retrieved_chunks

    top_chunk_snippet = retrieved_chunks[0]["text"][:200] if retrieved_chunks else ""

    if MOCK_LLM:
        # Mock mode (graded baseline): canned templated answer, no LLM call.
        answer = f"Based on the retrieved context: {top_chunk_snippet}"
        confidence = 1.0
    else:
        # Optional MOCK_LLM=0 extension: real LLM, grounded in retrieved chunks,
        # with schema-validated output + retry-on-failure.
        context_text = "\n---\n".join(c["text"] for c in retrieved_chunks)
        prompt = build_prompt(query=query, retrieved_context=context_text)
        structured = _generate_structured_answer_with_retry(prompt, [c["id"] for c in retrieved_chunks])
        state["answer"] = structured.answer
        state["sources"] = structured.sources
        state["confidence"] = structured.confidence
        return state

    state["answer"] = answer
    state["sources"] = [c["id"] for c in retrieved_chunks]
    state["confidence"] = confidence
    return state


def direct_answer(state: GraphState) -> GraphState:
    query = state["query"]
    if MOCK_LLM:
        # Mock mode (graded baseline): fixed canned string, no LLM call.
        answer = "I can only answer questions about Zepto policies right now."
    else:
        # Optional MOCK_LLM=0 extension: prompt the LLM directly, no retrieval,
        # with schema-validated output + retry-on-failure.
        structured = _generate_structured_answer_with_retry(
            f"Answer briefly and helpfully: {query}", allowed_sources=[]
        )
        state["answer"] = structured.answer
        state["sources"] = structured.sources
        state["confidence"] = structured.confidence
        return state

    state["answer"] = answer
    state["sources"] = []
    state["confidence"] = 1.0
    return state


def build_graph():
    graph = StateGraph(GraphState)
    graph.add_node("classify_intent", classify_intent)
    graph.add_node("retrieve_and_answer", retrieve_and_answer)
    graph.add_node("direct_answer", direct_answer)

    graph.set_entry_point("classify_intent")
    graph.add_conditional_edges(
        "classify_intent",
        route_by_intent,
        {"retrieve_and_answer": "retrieve_and_answer", "direct_answer": "direct_answer"},
    )
    graph.add_edge("retrieve_and_answer", END)
    graph.add_edge("direct_answer", END)

    return graph.compile()


_compiled_graph = None


def get_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph


def answer_query(query: str) -> AnswerResponse:
    graph = get_graph()
    result = graph.invoke(
        {"query": query, "intent": "", "retrieved_chunks": [], "answer": "", "sources": [], "confidence": 0.0}
    )
    return AnswerResponse(answer=result["answer"], sources=result["sources"], confidence=result["confidence"])
