# Module 3 — Support Assistant

A local RAG service answering questions about Zepto's own delivery, returns, membership,
tracking, cancellation, damaged/missing-items, gift-card, and support-hours policies.
**Fully offline and free by default**: embeddings run locally via `sentence-transformers`,
vectors are stored in a local ChromaDB, and every LLM call is gated behind `MOCK_LLM`
(default: mock/offline — no signup, no API key, no network call to any LLM provider).

## Install & run (graded baseline — MOCK_LLM left at default)

```bash
pip install -r requirements.txt
python ingest.py                              # embeds docs/ -> chroma_db/ (one-time)
uvicorn main:app --host 0.0.0.0 --port 7860    # auto-builds the index too if you skip ingest.py
```

```bash
curl -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "What is your delivery fee?"}'

curl -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the capital of France?"}'
```

### Example call transcripts (run with `MOCK_LLM` at its default)

**Call 1 — should trigger retrieval** (`"delivery"` keyword → `policy_question`):
```
POST /ask
{"query": "What is your delivery fee?"}

200 OK
{
  "answer": "Based on the retrieved context: Zepto delivers grocery and household essentials to serviceable pin codes within 10 to 30 minutes of order confirmation, depending on the customer's delivery zone and current order volume. Standard delivery is free on orders",
  "sources": ["doc_01"],
  "confidence": 1.0
}
```

**Call 2 — should NOT trigger retrieval** (no policy keyword → `general_question`):
```
POST /ask
{"query": "What is the capital of France?"}

200 OK
{
  "answer": "I can only answer questions about Zepto policies right now.",
  "sources": [],
  "confidence": 1.0
}
```

## Optional extensions (not required for grading)

- **Real LLM**: set `MOCK_LLM=0` and `GROQ_API_KEY=<your free-tier key>` to route
  `classify_intent` and generation through Groq (`llama-3.1-8b-instant`) instead of the
  mock logic. Any other genuinely-free LLM API is an acceptable substitute.
- **Hugging Face Spaces deployment**: build the same `Dockerfile` and push it to a free
  community CPU Space, storing `GROQ_API_KEY` as a Space secret (never committed). Not
  done in this submission — the required baseline is local Docker build/run only.

## Docker (required, graded baseline — local build/run only)

```bash
docker build -t zepto-support-assistant .
docker run -p 7860:7860 zepto-support-assistant
```

## Architecture: RAG pipeline walkthrough

```
docs/doc_01.txt ... doc_08.txt
        |  (ingestion: one chunk per doc — load_documents() in ingest.py)
        v
sentence-transformers "all-MiniLM-L6-v2"
        |  (embedding: model.encode(...) in ingest.py)
        v
ChromaDB PersistentClient, collection "zepto_policies"  (chroma_db/)
        |  (storage — populated once by ingest.py / auto-built on FastAPI startup)
        v
FastAPI  POST /ask  --calls-->  LangGraph StateGraph (graph.py)
        |
        +-- node: classify_intent
        |     mock mode (default): keyword heuristic over POLICY_KEYWORDS
        |     MOCK_LLM=0: LLM classifies instead
        |
        +-- conditional edge -> routes on intent
        |
        +-- node: retrieve_and_answer  (policy_question)
        |     retrieval ALWAYS real: embed query (same MiniLM model) ->
        |     collection.query(top_k=3) against ChromaDB (cosine similarity)
        |     generation branches on MOCK_LLM:
        |       mock (default): canned f"Based on the retrieved context: {snippet}"
        |       MOCK_LLM=0: prompt_template.build_prompt(...) -> real LLM ->
        |                   schema-validated JSON with retry (graph.py:
        |                   _generate_structured_answer_with_retry)
        |
        +-- node: direct_answer  (general_question)
              mock (default): fixed canned string, no retrieval, no LLM call
              MOCK_LLM=0: LLM answers directly, no retrieval
        |
        v
schemas.AnswerResponse (answer, sources, confidence) — Pydantic-validated,
returned as the /ask response body.
```

**Ingestion** is handled by `load_documents()` in `ingest.py` (one chunk per policy
document — each file is already a short, single-topic paragraph). **Embedding** is
`SentenceTransformer("all-MiniLM-L6-v2").encode(...)`, also in `ingest.py`. **Storage** is
the `zepto_policies` ChromaDB collection under `chroma_db/`. **Retrieval** happens inside
the `retrieve_and_answer` node in `graph.py`, which embeds the incoming query with the
same MiniLM model and calls `collection.query(...)` for the top-3 chunks by cosine
similarity. **Generation** happens at the end of `retrieve_and_answer` (grounded, policy
questions) or in `direct_answer` (ungrounded, general questions).

**MOCK_LLM branching**: only the *generation* step inside `classify_intent`,
`retrieve_and_answer`, and `direct_answer` branches on `MOCK_LLM` — ingestion, embedding,
and retrieval are identical in both modes since they need no API key or network call. In
its default (mock) state, no node ever calls an LLM: `classify_intent` uses a keyword
heuristic, `retrieve_and_answer` returns a canned template built from the top retrieved
chunk, and `direct_answer` returns a fixed string. In the optional `MOCK_LLM=0` state,
those same three steps instead call a real LLM (Groq free tier), with the structured
JSON schema output validated by Pydantic and retried up to 2 additional times on
validation failure before falling back to a clearly marked error response.

## Files

- `docs/doc_01.txt` … `doc_08.txt` — the 8 policy documents (verbatim, as specified).
- `ingest.py` — loads, chunks, embeds, and stores the corpus in ChromaDB.
- `prompt_template.py` — role/context/task/format/length prompt template with a negative
  constraint and a few-shot example (used only by the optional `MOCK_LLM=0` path).
- `graph.py` — the LangGraph `StateGraph` (3 nodes + conditional edge), MOCK_LLM
  branching, and the schema-validation retry logic.
- `schemas.py` — `AskRequest` / `AnswerResponse` Pydantic models.
- `main.py` — FastAPI app exposing `POST /ask`.
- `Dockerfile` — builds and runs the FastAPI app locally on port 7860.
