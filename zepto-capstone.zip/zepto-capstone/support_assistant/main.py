"""
Module 3 - Support Assistant
FastAPI wrapper around the LangGraph pipeline.

Run:
    uvicorn main:app --host 0.0.0.0 --port 7860

MOCK_LLM defaults to mock mode (graded baseline) - leave it unset, or set
MOCK_LLM=1, to run fully offline with no LLM calls.
"""

import os

import chromadb
from fastapi import FastAPI

from graph import answer_query
from ingest import COLLECTION_NAME, PERSIST_DIR, build_index
from schemas import AnswerResponse, AskRequest

app = FastAPI(title="Zepto Support Assistant")


@app.on_event("startup")
def ensure_index_built():
    """Convenience: if the ChromaDB collection doesn't exist yet (e.g. a
    fresh clone where `python ingest.py` wasn't run manually first), build
    it automatically on startup so `uvicorn main:app` just works."""
    client = chromadb.PersistentClient(path=PERSIST_DIR)
    existing = [c.name for c in client.list_collections()]
    if COLLECTION_NAME not in existing:
        build_index()


@app.get("/")
def root():
    return {"status": "ok", "service": "zepto-support-assistant"}


@app.post("/ask", response_model=AnswerResponse)
def ask(request: AskRequest) -> AnswerResponse:
    return answer_query(request.query)
