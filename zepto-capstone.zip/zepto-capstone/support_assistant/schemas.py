"""
Module 3 - Support Assistant
Pydantic models for the API request and the structured, validated answer.
"""

from typing import List

from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    query: str


class AnswerResponse(BaseModel):
    answer: str = Field(..., description="The final answer text shown to the user.")
    sources: List[str] = Field(
        default_factory=list,
        description="Chunk/document IDs used to ground the answer. Empty for general_question answers.",
    )
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score between 0 and 1.")
